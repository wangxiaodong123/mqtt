## Eclipse Paho MQTT Plugin

- Build the eclipse plugin and drop to the eclipse/plugins directory

- You will also need to install MQTT java client plugin