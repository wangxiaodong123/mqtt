#Android Service Client

#Generate JavaDoc  
1. Switch directory to ```cd org.eclipse.paho.android.service```
2. ```android update -p .```
3. Build Android project ```ant debug```
4. Documentation is in ```out\docs```

